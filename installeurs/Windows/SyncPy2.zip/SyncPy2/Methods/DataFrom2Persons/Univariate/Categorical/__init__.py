"""
This package allows to compute synchronisation between categorical monovariate signals gathered 
from two persons. 
"""

__all__ = ['Linear', 'Nonlinear', 'MachineLearning' ]
