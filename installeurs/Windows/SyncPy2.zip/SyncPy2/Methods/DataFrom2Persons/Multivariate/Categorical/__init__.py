"""
This package allows to compute synchronisation between categorical multivariate signals gathered 
from two persons. 
"""

__all__ = ['Linear', 'Nonlinear', 'MachineLearning' ]
