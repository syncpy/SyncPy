"""
This package allows to compute synchronisation between multivariate signals gathered 
from many persons. All the multivariate panda DataFrame describing each person should be then organized as a list. 
"""

__all__ = ['Categorical', 'Continuous']
