"""
This package allows to compute synchronisation between categorical multivariate data streams gathered 
from many persons. 
"""

__all__ = ['Linear', 'Nonlinear', 'MachineLearning' ]