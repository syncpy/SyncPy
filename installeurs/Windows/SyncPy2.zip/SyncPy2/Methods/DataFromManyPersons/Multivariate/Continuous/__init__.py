"""
This package allows to compute synchronisation between continuous multivariate data streams gathered 
from many persons. 
"""

__all__ = ['Linear', 'Nonlinear', 'MachineLearning' ]