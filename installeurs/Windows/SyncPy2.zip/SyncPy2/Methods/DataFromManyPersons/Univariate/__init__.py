"""
This package allows to compute synchronisation between monovariate signals gathered 
from many persons. 
"""

__all__ = ['Categorical', 'Continuous']
