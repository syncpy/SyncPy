"""
This package allows to compute synchronisation between categorical monovariate signals gathered 
from many persons. 
"""

__all__ = ['Linear', 'Nonlinear', 'MachineLearning' ]
