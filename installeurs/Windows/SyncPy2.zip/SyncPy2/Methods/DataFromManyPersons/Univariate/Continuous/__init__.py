"""
This package allows to compute synchronisation between continuous monovariate signals gathered 
from many persons. 
"""

__all__ = ['Linear', 'Nonlinear', 'MachineLearning' ]
