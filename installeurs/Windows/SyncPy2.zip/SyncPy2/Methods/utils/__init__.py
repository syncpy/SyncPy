"""
This package contains functionals of general utility directly used by synchrony methods or to preprocess the input signals
"""
